<?php
header('Content-Type: application/json');

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "coffee_shop";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get cart data from POST request
$cart = json_decode(file_get_contents('php://input'), true);

// Insert each item into the database
foreach ($cart as $item) {
    $productId = $item['id'];
    $productName = $item['name'];
    $productPrice = $item['price'];

    $sql = "INSERT INTO orders (product_id, product_name, product_price) VALUES ('$productId', '$productName', '$productPrice')";

    if (!$conn->query($sql)) {
        echo json_encode(['success' => false, 'error' => $conn->error]);
        exit;
    }
}

echo json_encode(['success' => true]);
$conn->close();
?>